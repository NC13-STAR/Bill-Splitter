# Bill Splitter Pro — MVP

Track ongoing shared expenses between roommates or couples with live running balances.

## Features
- Live balance calculation across all members
- Add expenses with custom payer + split configuration
- Settle up and record payments
- Category breakdown with visual bars
- Per-member net balance (owed / owes)

## Quick Start

```bash
npm install
npm start
```

App opens at http://localhost:3000

## Build for production

```bash
npm run build
```

Output goes to the `build/` folder — deploy to Vercel, Netlify, or any static host.

## Project structure

```
bill-splitter-pro/
├── public/
│   └── index.html
├── src/
│   ├── App.jsx       ← all logic + UI
│   └── index.jsx     ← React entry point
├── package.json
└── README.md
```

## Next steps to make it production-ready
- Add Firebase / Supabase for multi-device sync
- UPI deep-link on "Settle up": `upi://pay?pa=vpa@bank&am=AMOUNT`
- Push notifications via Firebase Cloud Messaging
- OCR bill scanning with Google Vision API
- WhatsApp reminder integration via Twilio / Meta API
- Monthly rollover so balances carry forward automatically
