import { useState, useMemo } from "react";

// ─── Constants ────────────────────────────────────────────────────────────────

const COLORS = [
  { bg: "#EEEDFE", text: "#3C3489", mid: "#7F77DD" },
  { bg: "#E1F5EE", text: "#085041", mid: "#1D9E75" },
  { bg: "#FAECE7", text: "#712B13", mid: "#D85A30" },
  { bg: "#FBEAF0", text: "#72243E", mid: "#D4537E" },
  { bg: "#E6F1FB", text: "#0C447C", mid: "#378ADD" },
];

const CATEGORIES = [
  { id: "rent",        label: "Rent",        icon: "ti-home" },
  { id: "groceries",   label: "Groceries",   icon: "ti-shopping-cart" },
  { id: "electricity", label: "Electricity", icon: "ti-bolt" },
  { id: "internet",    label: "Internet",    icon: "ti-wifi" },
  { id: "water",       label: "Water",       icon: "ti-droplet" },
  { id: "food",        label: "Food",        icon: "ti-tools-kitchen-2" },
  { id: "other",       label: "Other",       icon: "ti-dots" },
];

const INIT_MEMBERS = [
  { id: 1, name: "You",        initials: "ME", colorIdx: 0 },
  { id: 2, name: "Siddharth",  initials: "SK", colorIdx: 1 },
  { id: 3, name: "Priya",      initials: "PJ", colorIdx: 2 },
  { id: 4, name: "Mihir",      initials: "MR", colorIdx: 3 },
];

const INIT_EXPENSES = [
  { id: 1, desc: "Monthly rent",          amount: 40000, paidBy: 1, splitWith: [1,2,3,4], category: "rent",        date: "2026-06-01" },
  { id: 2, desc: "Big Basket groceries",  amount: 3200,  paidBy: 1, splitWith: [1,2,3,4], category: "groceries",   date: "2026-06-05" },
  { id: 3, desc: "Electricity — June",    amount: 2400,  paidBy: 4, splitWith: [1,2,3,4], category: "electricity", date: "2026-06-08" },
  { id: 4, desc: "Internet bill",         amount: 1499,  paidBy: 4, splitWith: [1,2,3,4], category: "internet",    date: "2026-06-10" },
  { id: 5, desc: "Water tanker",          amount: 800,   paidBy: 4, splitWith: [1,2,3,4], category: "water",       date: "2026-06-12" },
  { id: 6, desc: "Zomato group order",    amount: 1200,  paidBy: 2, splitWith: [1,2,3],   category: "food",        date: "2026-06-14" },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

const fmt = (n) => "₹" + Math.abs(Math.round(n)).toLocaleString("en-IN");

function computeBalances(members, expenses, settlements) {
  const bal = {};
  members.forEach((m) => (bal[m.id] = 0));
  expenses.forEach((e) => {
    const share = e.amount / e.splitWith.length;
    e.splitWith.forEach((mid) => {
      if (mid === e.paidBy) return;
      bal[e.paidBy] += share;
      bal[mid] -= share;
    });
  });
  settlements.forEach((s) => {
    bal[s.from] += s.amount;
    bal[s.to] -= s.amount;
  });
  return bal;
}

function computeOwes(members, balances) {
  const result = [];
  members
    .filter((m) => m.id !== 1)
    .forEach((m) => {
      const b = balances[m.id] || 0;
      if (b < -0.5) result.push({ from: m,           to: members[0], amount: -b });
      if (b >  0.5) result.push({ from: members[0],  to: m,          amount: b  });
    });
  return result;
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function Avatar({ member, size = 36 }) {
  const c = COLORS[member.colorIdx % COLORS.length];
  return (
    <div style={{
      width: size, height: size, borderRadius: "50%",
      background: c.bg, color: c.text,
      display: "flex", alignItems: "center", justifyContent: "center",
      fontSize: size * 0.35, fontWeight: 500, flexShrink: 0,
    }}>
      {member.initials}
    </div>
  );
}

function Toast({ message }) {
  if (!message) return null;
  return (
    <div style={{
      position: "fixed", bottom: 84, left: "50%", transform: "translateX(-50%)",
      background: "#1a1a1a", color: "#fff",
      padding: "9px 18px", borderRadius: 20, fontSize: 13, fontWeight: 500,
      zIndex: 200, display: "flex", alignItems: "center", gap: 6,
      whiteSpace: "nowrap",
    }}>
      <i className="ti ti-check" /> {message}
    </div>
  );
}

// ─── Add Expense Modal ────────────────────────────────────────────────────────

function AddExpenseModal({ members, onAdd, onClose }) {
  const [form, setForm] = useState({
    desc: "", amount: "", paidBy: 1, splitWith: [1, 2, 3, 4], category: "other",
  });

  const toggleSplit = (mid) =>
    setForm((f) => ({
      ...f,
      splitWith: f.splitWith.includes(mid)
        ? f.splitWith.filter((x) => x !== mid)
        : [...f.splitWith, mid],
    }));

  const handleAdd = () => {
    if (!form.desc.trim() || !form.amount || form.splitWith.length < 1) return;
    onAdd({ ...form, amount: parseFloat(form.amount), date: new Date().toISOString().slice(0, 10) });
    onClose();
  };

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      style={{
        position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)",
        display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 100,
      }}
    >
      <div style={{
        background: "#fff", borderRadius: "16px 16px 0 0",
        padding: "20px 16px 32px", width: "100%", maxWidth: 480,
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
          <p style={{ fontSize: 16, fontWeight: 500 }}>Add expense</p>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 20, color: "#888", cursor: "pointer" }}>
            <i className="ti ti-x" />
          </button>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <input
            value={form.desc}
            onChange={(e) => setForm((f) => ({ ...f, desc: e.target.value }))}
            placeholder="What was this for?"
            style={inputStyle}
          />
          <input
            value={form.amount}
            onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))}
            placeholder="₹ Amount"
            type="number"
            style={inputStyle}
          />

          <div>
            <p style={labelStyle}>Paid by</p>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              {members.map((m) => (
                <button
                  key={m.id}
                  onClick={() => setForm((f) => ({ ...f, paidBy: m.id }))}
                  style={pillStyle(form.paidBy === m.id, "#1a1a1a", "#fff")}
                >
                  {m.name}
                </button>
              ))}
            </div>
          </div>

          <div>
            <p style={labelStyle}>Split with</p>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              {members.map((m) => (
                <button
                  key={m.id}
                  onClick={() => toggleSplit(m.id)}
                  style={pillStyle(form.splitWith.includes(m.id), "#0F6E56", "#085041", "#E1F5EE")}
                >
                  {m.name}
                </button>
              ))}
            </div>
          </div>

          <div>
            <p style={labelStyle}>Category</p>
            <select
              value={form.category}
              onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
              style={{ ...inputStyle, appearance: "none" }}
            >
              {CATEGORIES.map((c) => (
                <option key={c.id} value={c.id}>{c.label}</option>
              ))}
            </select>
          </div>

          {form.amount && form.splitWith.length > 0 && (
            <p style={{ fontSize: 13, color: "#666", padding: "8px 12px", background: "#f5f5f3", borderRadius: 8 }}>
              {fmt(parseFloat(form.amount) / form.splitWith.length)} each · split {form.splitWith.length} ways
            </p>
          )}

          <button onClick={handleAdd} style={{
            width: "100%", padding: 11, background: "#1a1a1a", color: "#fff",
            border: "none", borderRadius: 8, fontSize: 14, fontWeight: 500, cursor: "pointer", marginTop: 2,
          }}>
            Add expense
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Settle Modal ─────────────────────────────────────────────────────────────

function SettleModal({ item, onSettle, onClose }) {
  const isYouOwe = item.from.id === 1;
  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      style={{
        position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)",
        display: "flex", alignItems: "center", justifyContent: "center",
        padding: 20, zIndex: 100,
      }}
    >
      <div style={{ background: "#fff", borderRadius: 16, padding: 24, width: "100%", maxWidth: 360 }}>
        <p style={{ fontSize: 16, fontWeight: 500, marginBottom: 8 }}>Settle up</p>
        <p style={{ fontSize: 14, color: "#666", marginBottom: 20 }}>
          {isYouOwe
            ? `You owe ${item.to.name} ${fmt(item.amount)}`
            : `${item.from.name} owes you ${fmt(item.amount)}`}
        </p>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={onClose} style={{
            flex: 1, padding: 10, background: "transparent",
            border: "0.5px solid #ccc", borderRadius: 8, fontSize: 14, cursor: "pointer",
          }}>
            Cancel
          </button>
          <button onClick={() => onSettle(item.from.id, item.to.id, item.amount)} style={{
            flex: 1, padding: 10, background: "#1a1a1a", color: "#fff",
            border: "none", borderRadius: 8, fontSize: 14, fontWeight: 500, cursor: "pointer",
          }}>
            Confirm {fmt(item.amount)}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Tabs ─────────────────────────────────────────────────────────────────────

function BalancesTab({ members, owes, balances, onSettle }) {
  return (
    <div>
      <Card title="Who owes who">
        {owes.length === 0 ? (
          <EmptyState icon="ti-check" text="All settled up!" />
        ) : (
          owes.map((o, i) => {
            const isYouOwe = o.from.id === 1;
            return (
              <div key={i} style={rowStyle(i < owes.length - 1)}>
                <Avatar member={isYouOwe ? o.to : o.from} size={38} />
                <div style={{ flex: 1 }}>
                  <p style={{ fontSize: 14 }}>
                    {isYouOwe
                      ? <><span>You owe </span><strong style={{ fontWeight: 500 }}>{o.to.name}</strong></>
                      : <><strong style={{ fontWeight: 500 }}>{o.from.name}</strong><span> owes you</span></>}
                  </p>
                  <p style={{ fontSize: 12, color: "#888", marginTop: 2 }}>Running balance</p>
                </div>
                <div style={{ textAlign: "right" }}>
                  <p style={{ fontSize: 15, fontWeight: 500, color: isYouOwe ? "#993C1D" : "#0F6E56" }}>
                    {fmt(o.amount)}
                  </p>
                  <button onClick={() => onSettle(o)} style={smallBtnStyle}>
                    {isYouOwe ? "Settle up" : "Remind"}
                  </button>
                </div>
              </div>
            );
          })
        )}
      </Card>

      <Card title="All members" style={{ marginTop: 12 }}>
        {members.map((m, i) => {
          const b = balances[m.id] || 0;
          return (
            <div key={m.id} style={rowStyle(i < members.length - 1)}>
              <Avatar member={m} size={34} />
              <p style={{ flex: 1, fontSize: 14 }}>{m.name}</p>
              <p style={{ fontSize: 14, fontWeight: 500, color: b >= 0 ? "#0F6E56" : "#993C1D" }}>
                {b >= 0 ? "+" : "-"}{fmt(b)}
              </p>
            </div>
          );
        })}
      </Card>
    </div>
  );
}

function ExpensesTab({ expenses, members, }) {
  const memberMap = {};
  members.forEach((m) => (memberMap[m.id] = m));
  const catMap = {};
  CATEGORIES.forEach((c) => (catMap[c.id] = c));

  return (
    <div>
      {expenses.slice().reverse().map((e) => {
        const payer = memberMap[e.paidBy];
        const cat = catMap[e.category] || catMap.other;
        const myShare = e.splitWith.includes(1) ? e.amount / e.splitWith.length : 0;
        const iPaid = e.paidBy === 1;

        return (
          <div key={e.id} style={{ background: "#fff", borderRadius: 12, border: "0.5px solid #e5e5e5", padding: "12px 14px", marginBottom: 10 }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
              <div style={{ width: 38, height: 38, background: "#f5f5f3", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <i className={`ti ${cat.icon}`} style={{ fontSize: 18, color: "#888" }} />
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: 14, fontWeight: 500 }}>{e.desc}</p>
                <p style={{ fontSize: 12, color: "#888", marginTop: 2 }}>
                  Paid by {iPaid ? "you" : payer?.name} · {e.date}
                </p>
              </div>
              <div style={{ textAlign: "right" }}>
                <p style={{ fontSize: 15, fontWeight: 500 }}>{fmt(e.amount)}</p>
                {myShare > 0 && (
                  <span style={{
                    fontSize: 11, marginTop: 3, padding: "2px 8px", borderRadius: 20,
                    background: iPaid ? "#EEEDFE" : "#FAECE7",
                    color: iPaid ? "#3C3489" : "#712B13",
                    display: "inline-block",
                  }}>
                    {iPaid ? `+${fmt(e.amount - myShare)}` : `-${fmt(myShare)}`}
                  </span>
                )}
              </div>
            </div>
            <div style={{ display: "flex", gap: 4, marginTop: 10, flexWrap: "wrap" }}>
              <Pill>{cat.label}</Pill>
              <Pill>split {e.splitWith.length} ways · {fmt(e.amount / e.splitWith.length)} each</Pill>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function HistoryTab({ expenses, settlements, members }) {
  const memberMap = {};
  members.forEach((m) => (memberMap[m.id] = m));
  const totalAll = expenses.reduce((s, e) => s + e.amount, 0);

  return (
    <div>
      <Card title="By category — June">
        {CATEGORIES.map((cat) => {
          const total = expenses.filter((e) => e.category === cat.id).reduce((s, e) => s + e.amount, 0);
          if (!total) return null;
          const pct = Math.round((total / totalAll) * 100);
          return (
            <div key={cat.id} style={{ padding: "10px 14px", borderBottom: "0.5px solid #f0f0f0" }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <i className={`ti ${cat.icon}`} style={{ fontSize: 16, color: "#888" }} />
                  <span style={{ fontSize: 14 }}>{cat.label}</span>
                </div>
                <span style={{ fontSize: 14, fontWeight: 500 }}>{fmt(total)}</span>
              </div>
              <div style={{ height: 4, background: "#f0f0f0", borderRadius: 4 }}>
                <div style={{ height: 4, width: `${pct}%`, background: "#7F77DD", borderRadius: 4 }} />
              </div>
            </div>
          );
        })}
      </Card>

      <Card title="Settlements" style={{ marginTop: 12 }}>
        {settlements.length === 0 ? (
          <EmptyState icon="ti-arrows-exchange" text="No settlements yet" />
        ) : (
          settlements.map((s, i) => (
            <div key={s.id} style={rowStyle(i < settlements.length - 1)}>
              <i className="ti ti-arrows-exchange" style={{ fontSize: 18, color: "#888" }} />
              <p style={{ flex: 1, fontSize: 14 }}>
                {memberMap[s.from]?.name} → {memberMap[s.to]?.name}
              </p>
              <p style={{ fontSize: 14, fontWeight: 500, color: "#0F6E56" }}>{fmt(s.amount)}</p>
            </div>
          ))
        )}
      </Card>
    </div>
  );
}

// ─── Shared UI helpers ────────────────────────────────────────────────────────

function Card({ title, children, style }) {
  return (
    <div style={{ background: "#fff", borderRadius: 12, border: "0.5px solid #e5e5e5", overflow: "hidden", ...style }}>
      <div style={{ padding: "12px 14px", borderBottom: "0.5px solid #f0f0f0" }}>
        <p style={{ fontSize: 12, fontWeight: 500, color: "#888", textTransform: "uppercase", letterSpacing: "0.05em" }}>{title}</p>
      </div>
      {children}
    </div>
  );
}

function EmptyState({ icon, text }) {
  return (
    <div style={{ padding: 28, textAlign: "center", color: "#aaa", fontSize: 14 }}>
      <i className={`ti ${icon}`} style={{ fontSize: 28, display: "block", marginBottom: 6 }} />
      {text}
    </div>
  );
}

function Pill({ children }) {
  return (
    <span style={{ fontSize: 11, background: "#f5f5f3", color: "#888", padding: "2px 8px", borderRadius: 20 }}>
      {children}
    </span>
  );
}

const inputStyle = {
  width: "100%", padding: "10px 12px",
  border: "0.5px solid #ccc", borderRadius: 8,
  fontSize: 14, background: "#fff", color: "#1a1a1a",
};

const labelStyle = { fontSize: 12, color: "#888", marginBottom: 6 };

const rowStyle = (hasBorder) => ({
  display: "flex", alignItems: "center", gap: 10,
  padding: "11px 14px",
  borderBottom: hasBorder ? "0.5px solid #f0f0f0" : "none",
});

const smallBtnStyle = {
  marginTop: 4, background: "transparent",
  border: "0.5px solid #ccc", borderRadius: 6,
  padding: "4px 10px", fontSize: 12, color: "#666", cursor: "pointer",
};

const pillStyle = (active, activeBg, activeText, activeBgLight) => ({
  padding: "6px 12px",
  border: `0.5px solid ${active ? activeBg : "#ccc"}`,
  borderRadius: 20, fontSize: 13, cursor: "pointer",
  background: active ? (activeBgLight || activeBg) : "transparent",
  color: active ? (activeBgLight ? activeText : "#fff") : "#666",
});

// ─── Root App ─────────────────────────────────────────────────────────────────

export default function App() {
  const [members] = useState(INIT_MEMBERS);
  const [expenses, setExpenses] = useState(INIT_EXPENSES);
  const [settlements, setSettlements] = useState([]);
  const [tab, setTab] = useState("balances");
  const [showAdd, setShowAdd] = useState(false);
  const [showSettle, setShowSettle] = useState(null);
  const [toast, setToast] = useState(null);

  const balances = useMemo(() => computeBalances(members, expenses, settlements), [members, expenses, settlements]);
  const owes = useMemo(() => computeOwes(members, balances), [members, balances]);
  const myNet = balances[1] || 0;
  const total = expenses.reduce((s, e) => s + e.amount, 0);

  const fireToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  };

  const handleAddExpense = (data) => {
    setExpenses((prev) => [...prev, { id: Date.now(), ...data }]);
    fireToast("Expense added");
  };

  const handleSettle = (fromId, toId, amount) => {
    setSettlements((prev) => [...prev, { id: Date.now(), from: fromId, to: toId, amount }]);
    setShowSettle(null);
    fireToast("Settlement recorded");
  };

  const TABS = ["balances", "expenses", "history"];

  return (
    <div style={{ minHeight: "100vh", background: "#f5f5f3", paddingBottom: 80 }}>
      {/* ── Header ── */}
      <div style={{ background: "#fff", borderBottom: "0.5px solid #e5e5e5", padding: "14px 16px 0" }}>
        <div style={{ maxWidth: 480, margin: "0 auto" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
            <div>
              <p style={{ fontSize: 20, fontWeight: 500 }}>Flat 4B</p>
              <p style={{ fontSize: 13, color: "#888", marginTop: 2 }}>June 2026 · {members.length} members</p>
            </div>
            <div style={{ display: "flex" }}>
              {members.map((m, i) => (
                <div key={m.id} style={{ marginLeft: i > 0 ? -8 : 0, zIndex: members.length - i }}>
                  <Avatar member={m} size={34} />
                </div>
              ))}
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
            <div style={{ background: "#f5f5f3", borderRadius: 8, padding: "10px 12px" }}>
              <p style={{ fontSize: 12, color: "#888", marginBottom: 2 }}>Total this month</p>
              <p style={{ fontSize: 20, fontWeight: 500 }}>{fmt(total)}</p>
            </div>
            <div style={{ background: myNet >= 0 ? "#E1F5EE" : "#FAECE7", borderRadius: 8, padding: "10px 12px" }}>
              <p style={{ fontSize: 12, color: myNet >= 0 ? "#085041" : "#712B13", marginBottom: 2 }}>Your net balance</p>
              <p style={{ fontSize: 20, fontWeight: 500, color: myNet >= 0 ? "#0F6E56" : "#993C1D" }}>
                {myNet >= 0 ? "+" : "-"}{fmt(myNet)}
              </p>
              <p style={{ fontSize: 11, color: myNet >= 0 ? "#085041" : "#712B13", marginTop: 1 }}>
                {myNet >= 0 ? "you are owed" : "you owe"}
              </p>
            </div>
          </div>

          <div style={{ display: "flex", gap: 4 }}>
            {TABS.map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                style={{
                  padding: "7px 14px", fontSize: 13, border: "none",
                  borderRadius: "8px 8px 0 0", background: "transparent", cursor: "pointer",
                  color: tab === t ? "#1a1a1a" : "#888",
                  fontWeight: tab === t ? 500 : 400,
                  borderBottom: tab === t ? "2px solid #1a1a1a" : "2px solid transparent",
                }}
              >
                {t.charAt(0).toUpperCase() + t.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ── Tab content ── */}
      <div style={{ maxWidth: 480, margin: "0 auto", padding: "14px 12px" }}>
        {tab === "balances" && (
          <BalancesTab members={members} owes={owes} balances={balances} onSettle={setShowSettle} />
        )}
        {tab === "expenses" && (
          <ExpensesTab expenses={expenses} members={members} />
        )}
        {tab === "history" && (
          <HistoryTab expenses={expenses} settlements={settlements} members={members} />
        )}
      </div>

      {/* ── FAB ── */}
      <button
        onClick={() => setShowAdd(true)}
        aria-label="Add expense"
        style={{
          position: "fixed", bottom: 24, right: 20,
          background: "#1a1a1a", color: "#fff",
          border: "none", borderRadius: "50%", width: 54, height: 54,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 24, cursor: "pointer", boxShadow: "0 2px 12px rgba(0,0,0,0.18)",
        }}
      >
        <i className="ti ti-plus" />
      </button>

      {/* ── Modals ── */}
      {showAdd && (
        <AddExpenseModal members={members} onAdd={handleAddExpense} onClose={() => setShowAdd(false)} />
      )}
      {showSettle && (
        <SettleModal item={showSettle} onSettle={handleSettle} onClose={() => setShowSettle(null)} />
      )}

      <Toast message={toast} />
    </div>
  );
}
